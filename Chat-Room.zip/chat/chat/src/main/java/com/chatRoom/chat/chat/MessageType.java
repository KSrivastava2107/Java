package com.chatRoom.chat.chat;

public enum MessageType {
    CHAT,
    JOIN,
    LEAVE
}
